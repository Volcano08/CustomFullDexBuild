// Desktop shortcuts for the PC all-games program (frontend/pc_launcher.cpp): one per game in the
// list, which starts that game straight away ("--game IREO"), with the game's picture as its icon.
// Windows: a .lnk on the desktop and an .ico beside the program (shortcut-icons/). Linux: a
// .desktop file in the applications menu (~/.local/share/applications) and on the desktop, with a
// .png icon. macOS: a small .app in ~/Applications and on the desktop.
#pragma once

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <set>
#include <string>
#include <vector>
#include <sys/stat.h>

#ifdef _WIN32
#include <windows.h>
#include <objbase.h>
#include <shlobj.h>
#include <shobjidl.h>
#include <knownfolders.h>
#include <propidl.h>
#include <propsys.h>
#else
#include <cstdlib>
#include <unistd.h>
#endif

#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif

#include "launcher.h"

namespace Shortcuts
{
// ---------------------------------------------------------------------------
// Pictures: the game's picture at the icon sizes, and as PNG files (uncompressed: the few
// hundred kilobytes do not matter, and no library is needed).

inline uint32_t Crc32(const uint8_t* p, size_t n, uint32_t crc = 0)
{
    static uint32_t table[256];
    static bool made = false;
    if (!made)
    {
        for (uint32_t i = 0; i < 256; i++)
        {
            uint32_t c = i;
            for (int k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320u ^ (c >> 1) : c >> 1;
            table[i] = c;
        }
        made = true;
    }
    crc = ~crc;
    for (size_t i = 0; i < n; i++) crc = table[(crc ^ p[i]) & 255] ^ (crc >> 8);
    return ~crc;
}

// ARGB pixels (w x h) as a PNG file.
inline std::vector<uint8_t> Png(const std::vector<uint32_t>& argb, int w, int h)
{
    std::vector<uint8_t> raw;
    raw.reserve((size_t)h * (w * 4 + 1));
    for (int y = 0; y < h; y++)
    {
        raw.push_back(0); // (no filter)
        for (int x = 0; x < w; x++)
        {
            const uint32_t p = argb[(size_t)y * w + x];
            raw.push_back((p >> 16) & 255);
            raw.push_back((p >> 8) & 255);
            raw.push_back(p & 255);
            raw.push_back(p >> 24);
        }
    }
    // zlib, with stored (uncompressed) deflate blocks.
    std::vector<uint8_t> z = { 0x78, 0x01 };
    for (size_t at = 0; at < raw.size() || at == 0;)
    {
        const size_t n = std::min<size_t>(65535, raw.size() - at);
        const bool last = at + n >= raw.size();
        z.push_back(last ? 1 : 0);
        z.push_back(n & 255);
        z.push_back(n >> 8);
        z.push_back(~n & 255);
        z.push_back((~n >> 8) & 255);
        z.insert(z.end(), raw.begin() + at, raw.begin() + at + n);
        at += n;
        if (last) break;
    }
    uint32_t a = 1, b = 0;
    for (uint8_t c : raw)
    {
        a = (a + c) % 65521;
        b = (b + a) % 65521;
    }
    const uint32_t adler = (b << 16) | a;
    for (int s = 24; s >= 0; s -= 8) z.push_back((adler >> s) & 255);

    std::vector<uint8_t> out = { 0x89, 'P', 'N', 'G', '\r', '\n', 0x1A, '\n' };
    auto chunk = [&](const char* type, const std::vector<uint8_t>& data) {
        const uint32_t n = (uint32_t)data.size();
        for (int s = 24; s >= 0; s -= 8) out.push_back((n >> s) & 255);
        std::vector<uint8_t> td(type, type + 4);
        td.insert(td.end(), data.begin(), data.end());
        out.insert(out.end(), td.begin(), td.end());
        const uint32_t crc = Crc32(td.data(), td.size());
        for (int s = 24; s >= 0; s -= 8) out.push_back((crc >> s) & 255);
    };
    std::vector<uint8_t> ihdr;
    for (int v : { w, h })
        for (int s = 24; s >= 0; s -= 8) ihdr.push_back((v >> s) & 255);
    ihdr.insert(ihdr.end(), { 8, 6, 0, 0, 0 }); // 8 bits, RGBA
    chunk("IHDR", ihdr);
    chunk("IDAT", z);
    chunk("IEND", {});
    return out;
}

// The game's picture at side m (Launcher::GamePicture).
inline std::vector<uint32_t> Picture(const Launcher::Game& g, int m) { return Launcher::GamePicture(g, m); }

inline bool WriteFile(const std::string& path, const std::vector<uint8_t>& data)
{
    FILE* f = fopen(path.c_str(), "wb");
    if (!f) return false;
    const bool ok = fwrite(data.data(), 1, data.size(), f) == data.size();
    return fclose(f) == 0 && ok;
}

// The shortcut's name: the game's ("Pokemon Black 2"), or the player's own for it (RENAME), as a
// file name (without the \ / : * ? " < > | Windows will not have in one).
inline std::string Title(const Launcher::Game& g)
{
    std::string t;
    for (char c : Launcher::DisplayName(g))
        t += (unsigned char)c < 0x20 || strchr("\\/:*?\"<>|", c) ? ' ' : c;
    while (!t.empty() && (t.back() == ' ' || t.back() == '.')) t.pop_back();
    while (!t.empty() && t[0] == ' ') t.erase(0, 1);
    return t.empty() ? "Pokemon DS " + g.code : t;
}

// What "--game" starts the game by (Launcher::GameArg: its code, or its ROM's file name when the
// list has more than one ROM of the game), and a short name for its icon and launcher files from
// that: the code (IREO), or the code and a number made from the file name (IPKE-1A2B3C4D).
inline std::string FileKey(const std::string& code, const std::string& arg)
{
    if (arg == code) return code;
    uint32_t h = 2166136261u; // (FNV-1a, of the name in capitals as --game takes it)
    for (char c : Launcher::Upper(arg)) h = (h ^ (uint8_t)c) * 16777619u;
    char buf[16];
    snprintf(buf, sizeof buf, "-%08X", (unsigned)h);
    return code + buf;
}

#ifdef _WIN32
inline std::wstring Wide(const std::string& s)
{
    std::wstring w(s.size() + 1, L'\0');
    const int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, &w[0], (int)w.size());
    w.resize(n > 0 ? n - 1 : 0);
    for (wchar_t& c : w)
        if (c == L'/') c = L'\\';
    return w;
}

// An .ico holding the picture as PNGs at 256, 48, 32 and 16 pixels.
inline std::vector<uint8_t> Ico(const Launcher::Game& g)
{
    const int sizes[] = { 256, 48, 32, 16 };
    std::vector<std::vector<uint8_t>> pngs;
    for (int s : sizes)
    {
        const std::vector<uint32_t> px = Picture(g, s);
        if (px.empty()) return {};
        pngs.push_back(Png(px, s, s));
    }
    std::vector<uint8_t> out = { 0, 0, 1, 0, (uint8_t)pngs.size(), 0 };
    uint32_t offset = 6 + 16 * (uint32_t)pngs.size();
    auto u16 = [&](uint32_t v) { out.push_back(v & 255); out.push_back((v >> 8) & 255); };
    auto u32 = [&](uint32_t v) { u16(v & 0xFFFF); u16(v >> 16); };
    for (size_t i = 0; i < pngs.size(); i++)
    {
        out.push_back(sizes[i] >= 256 ? 0 : sizes[i]);
        out.push_back(sizes[i] >= 256 ? 0 : sizes[i]);
        out.push_back(0);
        out.push_back(0);
        u16(1);
        u16(32);
        u32((uint32_t)pngs[i].size());
        u32(offset);
        offset += (uint32_t)pngs[i].size();
    }
    for (auto& p : pngs) out.insert(out.end(), p.begin(), p.end());
    return out;
}
#endif

#ifdef _WIN32
// The taskbar's names for the program (the game list, and a game started from it) and for each
// game started from its desktop shortcut. Windows groups the windows on the taskbar, and shows
// their icon, by these: without them every window of the program counted as any shortcut to it
// that was pinned (Platinum's, say), and showed that game's picture.
// game: what --game names it by (FileKey): a game code as it always was; a ROM's file name as a
// number made from it (ROM1A2B3C4D), an ID having no spaces or dots.
inline std::wstring AppId(const std::string& game)
{
    std::string id = Launcher::Upper(game);
    if (id.find_first_not_of("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-") != std::string::npos) id = "ROM" + FileKey("", game).substr(1);
    return id.empty() ? L"mamesj.PokemonDSWide" : L"mamesj.PokemonDSWide." + std::wstring(id.begin(), id.end());
}

// This process's taskbar name: before any window is made.
inline void SetAppId(const std::string& code)
{
    typedef HRESULT(WINAPI * SetId)(PCWSTR);
    if (HMODULE shell = GetModuleHandleW(L"shell32.dll"))
        if (auto set = (SetId)(void*)GetProcAddress(shell, "SetCurrentProcessExplicitAppUserModelID"))
            set(AppId(code).c_str());
}
#endif

#ifdef __APPLE__
inline std::string XmlText(const std::string& text)
{
    std::string out;
    for (char c : text)
    {
        if (c == '&') out += "&amp;";
        else if (c == '<') out += "&lt;";
        else if (c == '>') out += "&gt;";
        else out += c;
    }
    return out;
}

// An .icns holding the picture as PNGs at 128, 256 and 512 pixels (ic07, ic08, ic09).
inline std::vector<uint8_t> Icns(const Launcher::Game& g)
{
    const struct { const char* type; int size; } kinds[] = { { "ic07", 128 }, { "ic08", 256 }, { "ic09", 512 } };
    std::vector<uint8_t> out = { 'i', 'c', 'n', 's', 0, 0, 0, 0 };
    auto u32 = [&](uint32_t v) { for (int s = 24; s >= 0; s -= 8) out.push_back((v >> s) & 255); };
    for (const auto& k : kinds)
    {
        const std::vector<uint32_t> px = Picture(g, k.size);
        if (px.empty()) return {};
        const std::vector<uint8_t> png = Png(px, k.size, k.size);
        out.insert(out.end(), k.type, k.type + 4);
        u32(8 + (uint32_t)png.size());
        out.insert(out.end(), png.begin(), png.end());
    }
    const uint32_t total = (uint32_t)out.size();
    for (int i = 0; i < 4; i++) out[4 + i] = (total >> (24 - 8 * i)) & 255;
    return out;
}
#endif

// Whether a shortcut is made for the game: one per game and name, so the same game in several
// folders gets one (for the first), and each hack of a game the player renamed its own.
inline bool Wanted(const Launcher::Game& g, std::set<std::string>& done)
{
    return g.known && !g.comingSoon && done.insert(g.code + "|" + Launcher::Upper(Title(g))).second;
}

// Makes the shortcuts (Wanted). dir is the program's folder (for the icons). Returns how many were
// made; where says where they went, or what failed.
inline int Make(const std::string& dir, const std::vector<Launcher::Game>& games, std::string& where)
{
    std::set<std::string> done;
    int made = 0;
    const std::string iconDir = dir + "/shortcut-icons";
#ifdef _WIN32
    _wmkdir(Wide(iconDir).c_str());
    wchar_t exe[32768];
    const DWORD n = GetModuleFileNameW(nullptr, exe, 32768);
    if (n == 0 || n >= 32768)
    {
        where = "NO PROGRAM PATH";
        return 0;
    }
    PWSTR desktop = nullptr;
    if (FAILED(SHGetKnownFolderPath(FOLDERID_Desktop, 0, nullptr, &desktop)))
    {
        where = "NO DESKTOP FOLDER";
        return 0;
    }
    const std::wstring desk = desktop;
    CoTaskMemFree(desktop);
    const HRESULT init = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    for (const Launcher::Game& g : games)
    {
        if (!Wanted(g, done)) continue;
        const std::string arg = Launcher::GameArg(games, g);
        IShellLinkW* link = nullptr;
        if (FAILED(CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER, IID_IShellLinkW, (void**)&link))) break;
        link->SetPath(exe);
        // (A ROM's file name in quotes: it may have spaces. Windows file names have no quotes.)
        link->SetArguments((L"--game " + (arg == g.code ? Wide(arg) : L"\"" + Wide(arg) + L"\"")).c_str());
        link->SetWorkingDirectory(Wide(dir).c_str());
        link->SetDescription(Wide(Title(g) + " (Pokémon Fulldex)").c_str());
        const std::vector<uint8_t> ico = Ico(g);
        const std::string icoPath = iconDir + "/" + FileKey(g.code, arg) + ".ico";
        if (!ico.empty() && WriteFile(icoPath, ico)) link->SetIconLocation(Wide(icoPath).c_str(), 0);
        // (The game's own taskbar name, as the program takes when started with --game: SetAppId.)
        IPropertyStore* props = nullptr;
        if (SUCCEEDED(link->QueryInterface(IID_IPropertyStore, (void**)&props)))
        {
            // PKEY_AppUserModel_ID
            static const PROPERTYKEY key = { { 0x9F4C2855, 0x9F79, 0x4B39, { 0xA8, 0xD0, 0xE1, 0xD4, 0x2D, 0xE1, 0xD5, 0xF3 } }, 5 };
            const std::wstring id = AppId(arg);
            PROPVARIANT v;
            PropVariantInit(&v);
            v.vt = VT_LPWSTR;
            v.pwszVal = (LPWSTR)CoTaskMemAlloc((id.size() + 1) * sizeof(wchar_t));
            if (v.pwszVal)
            {
                memcpy(v.pwszVal, id.c_str(), (id.size() + 1) * sizeof(wchar_t));
                if (SUCCEEDED(props->SetValue(key, v))) props->Commit();
            }
            PropVariantClear(&v);
            props->Release();
        }
        IPersistFile* file = nullptr;
        if (SUCCEEDED(link->QueryInterface(IID_IPersistFile, (void**)&file)))
        {
            if (SUCCEEDED(file->Save((desk + L"\\" + Wide(Title(g)) + L".lnk").c_str(), TRUE))) made++;
            file->Release();
        }
        link->Release();
        fprintf(stderr, "[launcher] desktop shortcut for %s (%s)\n", arg.c_str(), Title(g).c_str());
    }
    if (SUCCEEDED(init)) CoUninitialize();
    // Explorer redraws the desktop with the new icons.
    SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, nullptr, nullptr);
    where = "ON YOUR DESKTOP";
#elif defined(__APPLE__)
    char exe[4096];
    uint32_t size = sizeof exe;
    if (_NSGetExecutablePath(exe, &size) != 0)
    {
        where = "NO PROGRAM PATH";
        return 0;
    }
    const char* homeEnv = getenv("HOME");
    if (!homeEnv || !*homeEnv) { where = "NO HOME FOLDER"; return 0; }
    const std::string home = homeEnv;
    // ~/Applications, where Spotlight and Launchpad find the games, and the desktop.
    const std::string apps = home + "/Applications";
    mkdir(apps.c_str(), 0755);
    const std::string desk = home + "/Desktop";
    struct stat st;
    const bool hasDesk = stat(desk.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
    // (The program's path, and a ROM's file name, in single quotes for the script, each quote in
    // it as '\''.)
    auto shQuoted = [](const std::string& text) {
        std::string q = "'";
        for (char c : text) q += c == '\'' ? std::string("'\\''") : std::string(1, c);
        return q + "'";
    };
    const std::string quoted = shQuoted(exe);
    for (const Launcher::Game& g : games)
    {
        if (!Wanted(g, done)) continue;
        const std::string arg = Launcher::GameArg(games, g), key = FileKey(g.code, arg);
        std::string lower = key;
        for (char& c : lower) c = (char)tolower((unsigned char)c);
        // The app is a shell script that starts the program on the game; the program, inside
        // its own .app, still uses the current Fulldex data folders.
        const std::string script = "#!/bin/sh\nexec " + quoted + " --game " + (arg == g.code ? arg : shQuoted(arg)) + "\n";
        const std::string plist =
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
            "<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n"
            "<plist version=\"1.0\">\n<dict>\n"
            "    <key>CFBundleExecutable</key><string>launch</string>\n"
            "    <key>CFBundleIconFile</key><string>icon</string>\n"
            "    <key>CFBundleIdentifier</key><string>io.github.mamesj.pokemonds." + lower + "</string>\n"
            "    <key>CFBundleName</key><string>" + XmlText(Title(g)) + "</string>\n"
            "    <key>CFBundlePackageType</key><string>APPL</string>\n"
            "    <key>LSApplicationCategoryType</key><string>public.app-category.games</string>\n"
            "    <key>LSMinimumSystemVersion</key><string>11.0</string>\n"
            "</dict>\n</plist>\n";
        const std::vector<uint8_t> icns = Icns(g);
        bool ok = true;
        for (const std::string& base : { apps, desk })
        {
            if (base == desk && !hasDesk) continue;
            const std::string app = base + "/" + Title(g) + ".app";
            for (const char* sub : { "", "/Contents", "/Contents/MacOS", "/Contents/Resources" })
                mkdir((app + sub).c_str(), 0755);
            ok = WriteFile(app + "/Contents/Info.plist", std::vector<uint8_t>(plist.begin(), plist.end())) && ok;
            const std::string run = app + "/Contents/MacOS/launch";
            ok = WriteFile(run, std::vector<uint8_t>(script.begin(), script.end())) && chmod(run.c_str(), 0755) == 0 && ok;
            if (!icns.empty()) WriteFile(app + "/Contents/Resources/icon.icns", icns);
        }
        if (ok) made++;
        fprintf(stderr, "[launcher] shortcut for %s (%s)\n", arg.c_str(), Title(g).c_str());
    }
    where = hasDesk ? "ON YOUR DESKTOP AND IN YOUR APPS" : "IN YOUR APPS";
#else
    mkdir(iconDir.c_str(), 0755);
    char exe[4096];
    const ssize_t n = readlink("/proc/self/exe", exe, sizeof exe - 1);
    if (n <= 0)
    {
        where = "NO PROGRAM PATH";
        return 0;
    }
    exe[n] = 0;
    // From an AppImage: the AppImage file itself (the program inside lives only while it runs).
    if (const char* appImage = getenv("APPIMAGE"); appImage && *appImage && strlen(appImage) < sizeof exe)
        strcpy(exe, appImage);
    const char* homeEnv = getenv("HOME");
    const std::string home = homeEnv ? homeEnv : "";
    // The applications menu (and Steam's "Add a Non-Steam Game" list on the Steam Deck).
    const std::string dataHome = getenv("XDG_DATA_HOME") && *getenv("XDG_DATA_HOME") ? getenv("XDG_DATA_HOME") : home + "/.local/share";
    const std::string apps = dataHome + "/applications";
    // (Each folder on the way, as mkdir -p: a new account may have no ~/.local yet.)
    for (size_t i = 1; i <= apps.size(); i++)
        if (i == apps.size() || apps[i] == '/') mkdir(apps.substr(0, i).c_str(), 0755);
    // The desktop folder: XDG_DESKTOP_DIR from ~/.config/user-dirs.dirs, else ~/Desktop.
    std::string desk = home + "/Desktop";
    if (FILE* f = fopen((home + "/.config/user-dirs.dirs").c_str(), "r"))
    {
        char line[1024];
        while (fgets(line, sizeof line, f))
        {
            std::string l = line;
            if (l.compare(0, 16, "XDG_DESKTOP_DIR=") != 0) continue;
            l = l.substr(16);
            while (!l.empty() && (l.back() == '\n' || l.back() == '\r' || l.back() == '"')) l.pop_back();
            if (!l.empty() && l[0] == '"') l = l.substr(1);
            if (l.compare(0, 5, "$HOME") == 0) l = home + l.substr(5);
            desk = l;
        }
        fclose(f);
    }
    struct stat st;
    const bool hasDesk = stat(desk.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
    // (A path in Exec is quoted, with its backslashes, quotes, backticks and dollars escaped, and
    // a % doubled, as Exec's own codes start with one.)
    auto execQuoted = [](const std::string& s) {
        std::string q = "\"";
        for (char c : s)
        {
            // (The file's own escaping doubles the backslash the Exec rules want before these.)
            if (c == '\\') q += "\\\\\\\\";
            else if (c == '%') q += "%%";
            else
            {
                if (c == '"' || c == '`' || c == '$') q += "\\\\";
                q += c;
            }
        }
        return q + "\"";
    };
    const std::string quoted = execQuoted(exe);
    for (const Launcher::Game& g : games)
    {
        if (!Wanted(g, done)) continue;
        const std::string arg = Launcher::GameArg(games, g), key = FileKey(g.code, arg);
        const std::string png = iconDir + "/" + key + ".png";
        const std::vector<uint32_t> px = Picture(g, 256);
        const bool icon = !px.empty() && WriteFile(png, Png(px, 256, 256));
        std::string lower = key;
        for (char& c : lower) c = (char)tolower((unsigned char)c);
        const std::string entry = "[Desktop Entry]\nType=Application\nName=" + Title(g) +
            "\nComment=Pokémon Fulldex\nExec=" + quoted + " --game " + (arg == g.code ? arg : execQuoted(arg)) +
            "\nPath=" + dir + "\n" + (icon ? "Icon=" + png + "\n" : "") + "Terminal=false\nCategories=Game;\n";
        const std::string file = "pokemon-ds-wide-" + lower + ".desktop";
        bool ok = WriteFile(apps + "/" + file, std::vector<uint8_t>(entry.begin(), entry.end()));
        if (hasDesk)
        {
            const std::string d = desk + "/" + file;
            ok = WriteFile(d, std::vector<uint8_t>(entry.begin(), entry.end())) && ok;
            chmod(d.c_str(), 0755); // (desktops start only launchers marked as programs)
        }
        if (ok) made++;
        fprintf(stderr, "[launcher] shortcut for %s (%s)\n", arg.c_str(), Title(g).c_str());
    }
    where = hasDesk ? "ON YOUR DESKTOP AND IN YOUR APPS" : "IN YOUR APPS MENU";
#endif
    return made;
}
}
