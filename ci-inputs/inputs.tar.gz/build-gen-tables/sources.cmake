set(RC_GENERATED_SOURCES
    "${CMAKE_CURRENT_LIST_DIR}/rc_tables.cpp"
    "${CMAKE_CURRENT_LIST_DIR}/rc_portable.cpp"
)
